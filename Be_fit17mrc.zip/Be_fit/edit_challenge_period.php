<?php 
session_start();
include 'config.php';
if(!isset($_SESSION['id']))  
{
echo "<script>window.location.href='index.php';</script>";
} 
?>
<!DOCTYPE html>
<html>
<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">
	<title>Be International</title>

	<!-- Site favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="vendors/imagelogo.png">
	<link rel="icon" type="image/png" sizes="32x32" href="vendors/imagelogo.png">
	<link rel="icon" type="image/png" sizes="16x16" href="vendors/imagelogo.png">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
</head>
<body>
	<?php include "header.php";?>
	<?php include "sidebar.php";?>
	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<!--<div class="page-header">
					<div class="row">-->
						<!--<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Form</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Form Basic</li>
								</ol>
							</nav>
						</div>-->
						<!--<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<a class="btn btn-secondary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
									January 2018
								</a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="#">Export List</a>
									<a class="dropdown-item" href="#">Policies</a>
									<a class="dropdown-item" href="#">View Assets</a>
								</div>
							</div>
						</div>-->
					<!--</div>
				</div>-->
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Edit Challenge Period</h4>
							<!--<p class="mb-30">All bootstrap element classies</p>-->
						</div>
						<div class="pull-right">
							<!--<a href="#basic-form1" class="btn btn-primary btn-sm scroll-click" rel="content-y"  data-toggle="collapse" role="button"><i class="fa fa-code"></i> Source Code</a>-->
						</div>
					</div>
					<?php 
					if($_GET['eid'])
					{
					  $chl=mysqli_query($con,"select * from tbl_challenges where cid='".$_GET['eid']."'");  
					  $chll=mysqli_fetch_assoc($chl);
					}
					if(isset($_POST['submit']) && !empty($_POST['submit']))
					{
					  $title = $_POST['title']; 
					  $start_date = $_POST['start_date']; 
					  $end_date = $_POST['end_date']; 
					  $submission_date = $_POST['submission_date']; 
					  
					  $inst=mysqli_query($con,"update `tbl_challenges` set `title`='$title', `start_date`='$start_date', `end_date`='$end_date', `submission_date`='$submission_date' where cid='".$_GET['eid']."'");  
					  //$id=mysqli_insert_id($con);
					  if($inst)
                        {
                            $perr="Update Success";
                            echo "<script type='text/javascript'>alert(\"$perr\");</script>";
                            echo'<script>window.location="add_challenge_period.php";</script>';
                        }
                        else
                        {
                            $perr= "Unable to update";
                            echo "<script type='text/javascript'>alert(\"$perr\");</script>";
                            //echo'<script>window.location="add_challenge_period.php";</script>';
                        }
					}
					?>
					<form method="post" enctype="multipart/form-data">
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Title</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control" name="title" type="text" placeholder="" value="<?php echo $chll['title'];?>">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Registration Start Date</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control" name="start_date" placeholder="" type="date" value="<?php echo $chll['start_date'];?>">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Registration End Date</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control" name="end_date"  type="date" value="<?php echo $chll['end_date'];?>">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-12 col-md-2 col-form-label">Last Submission Date</label>
							<div class="col-sm-12 col-md-10">
								<input class="form-control" name="submission_date" type="date" value="<?php echo $chll['submission_date'];?>">
							</div>
						</div>
						<input type="submit" class="btn btn-primary" name="submit" value="Submit">
					</form>
				</div>
				<!-- Default Basic Forms End -->
			</div>
			<br>
		<!--	<?php include "footer.php";?>-->
		</div>
	</div>
	<!-- js -->
	<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>
</body>
</html>