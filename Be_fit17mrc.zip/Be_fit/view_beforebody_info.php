<?php 
session_start();
include 'config.php';
if(!isset($_SESSION['id']))  
{
echo "<script>window.location.href='index.php';</script>";
} 
?>
<!DOCTYPE html>
<html>
<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">
	<title>Be International</title>

	<!-- Site favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="vendors/imagelogo.png">
	<link rel="icon" type="image/png" sizes="32x32" href="vendors/imagelogo.png">
	<link rel="icon" type="image/png" sizes="16x16" href="vendors/imagelogo.png">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
</head>
<body>
<?php include "header.php";?>
	<?php include "sidebar.php";?>
	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<!--<div class="page-header">
					<div class="row">-->
						<!--<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>DataTable</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">DataTable</li>
								</ol>
							</nav>
						</div>-->
						<!--<div class="col-md-6 col-sm-12 text-right">
							<div class="dropdown">
								<a class="btn btn-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
									January 2018
								</a>
								<div class="dropdown-menu dropdown-menu-right">
									<a class="dropdown-item" href="#">Export List</a>
									<a class="dropdown-item" href="#">Policies</a>
									<a class="dropdown-item" href="#">View Assets</a>
								</div>
							</div>
						</div>-->
				<!--	</div>
				</div>-->
				<!-- Export Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">View Before Body Information</h4>
					</div>
					<div class="pb-20">
						<table class="table hover multiple-select-row data-table-export nowrap">
							<thead>
								<tr>
								    <th class="table-plus datatable-nosort">S No.</th>
									<th>Ibo Id</th>
									<th>Name</th>
									<th>Dob</th>
									<th>Age</th>
									<th>Gender</th>
									<th>Email</th>
									<th>Phone</th>
									<th>State</th>
									<th>Country</th>
									<th>Height</th>
									<th>Weight</th>
									<th>Bmi</th>
									<th>Body Fat</th>
									<th>Visceral Fat</th>
									<th>Skeletal Muscle</th>
									<th>Biological Age</th>
									<th>Front Image</th>
									<th>Back Image</th>
									<th>Left Image</th>
									<th>Right Image</th>
									<th>Video</th>
									<th>Start Date</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							    <?php 
							    $count=1;
							    $usr=mysqli_query($con,"select * from tbl_body_information order by user_id desc");
							    while($usrr=mysqli_fetch_assoc($usr))
							    {
							        
							    ?>
								<tr>
									<td class="table-plus"><?php echo $count++;?></td>
									<td><?php echo $usrr['ibo_id'];?></td>
									<td><?php echo $usrr['name'];?></td>
									<td><?php echo $usrr['dob'];?></td>
									<td><?php echo $usrr['age'];?></td>
									<td><?php echo $usrr['gender'];?></td>
									<td><?php echo $usrr['email'];?></td>
									<td><?php echo $usrr['phone'];?></td>
									<td><?php echo $usrr['state'];?></td>
									<td><?php echo $usrr['country'];?></td>
									<td><?php echo $usrr['height'];?></td>
									<td><?php echo $usrr['weight'];?></td>
									<td><?php echo $usrr['bmi'];?></td>
									<td><?php echo $usrr['body_fat'];?></td>
									<td><?php echo $usrr['visceral_fat'];?></td>
									<td><?php echo $usrr['skeletal_muscle'];?></td>
									<td><?php echo $usrr['biological_age'];?></td>
									<td><img src="images/<?php echo $usrr['front_image'];?>" style="width:50px;height:50px;"></td>
									<td><img src="images/<?php echo $usrr['back_image'];?>" style="width:50px;height:50px;"></td>
									<td><img src="images/<?php echo $usrr['left_image'];?>" style="width:50px;height:50px;"></td>
									<td><img src="images/<?php echo $usrr['right_image'];?>" style="width:50px;height:50px;"></td>
									<td>
                                    <video style="width:50%;height:50%;" controls>
                                    <source src="video/<?php echo $usrr['video'];?>">
                                    </video>
                                    </td>
									<td><?php echo $usrr['start_date'];?></td>
									<td><!--<a href="edit_user_register.php?eid=<?php echo $usrr['user_id']; ?>"><button type="button" class="btn btn-primary">Update</button></a>-->
									<a href="view_beforebody_info.php?id=<?php echo $usrr['user_id'];?>" onclick="return confirm('Are you sure? You want to delete.')"><button type="button" class="btn btn-danger">Delete</button></a></td>
							    </tr>
								<?php }?>
							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
			<br><br><br><br>
			<!--<?php include "footer.php";?>-->
		</div>
	</div>
	<?php
    if($_GET['id'])
    {
        $id=$_GET['id'];
        $del=mysqli_query($con,"DELETE FROM tbl_body_information WHERE user_id='$id'");
        if($del)
        {
            //$del1=mysqli_query($con,"delete from user_register where user_id='$id'");
            
            $c="Delete sucessfully";
            echo "<script type='text/Javascript'>alert(\"$c\");</script>";
            echo'<script>window.location="view_beforebody_info.php";</script>';
        }
        else
        {
            $c="Not Deleted";
            echo "<script type='text/Javascript'>alert(\"$c\")'</script>";
            
        }
        }
    ?>
	<!-- js -->
	<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>
	<script src="src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/js/vfs_fonts.js"></script>
	<!-- Datatable Setting js -->
	<script src="vendors/scripts/datatable-setting.js"></script></body>
</html>