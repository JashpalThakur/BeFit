<?php 
include('config.php');

 $d= $_GET['d'];
 $uid = $_GET['uid'];
 $day = $_GET['day'];
  $someJSON = $d; //'[{"name":"Jonathan Suh","gender":"male"},{"name":"William Philbin","gender":"male"},{"name":"Allison McKinnery","gender":"female"}]';
  // Convert JSON string to Array
  $someArray = json_decode($someJSON, true);
//  print_r($someArray);        // Dump all data of the Array
//   $someArray[0]["calories"].'/n/'; // Access Array data
//   $someArray[1]["gender"]; 
  $itemNr = 0;
  $id=[];
  $mark_id=[];
 foreach($someArray as $item) {

  $gid=$item['calories'];
  //$id[] = $gid;
 $ss=mysqli_query($con,"SELECT * FROM match_all_data WHERE gameId='$gid'");
 $rr=mysqli_fetch_assoc($ss);
 $gameid=$rr['gameId'];
  if($gid==$gameid)
  {
      //echo "Data Exist";
  }
  else
  {
  $sql=mysqli_query($con,"INSERT INTO `tbl_calories`(`user_id`, `day`, `calorie`) VALUES('$uid','$day','$d')");
  }
$itemNr++;    
}
?>