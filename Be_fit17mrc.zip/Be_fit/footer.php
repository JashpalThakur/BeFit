<div class="footer-wrap pd-20 mb-20 card-box">
All Rights Reserved by BE INTERNATIONAL. Designed and Developed by. <a href="https://donationformynation.com/" target="_blank">CISS</a>
</div>