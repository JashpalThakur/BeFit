<?php
include('config.php');
$user_id = $_REQUEST['user_id'];
$day = $_REQUEST['food_type'];
$food_name = $_REQUEST['food_name'];
// $lunch_cal = $_REQUEST['lunch'];
// $dinner_cal = $_REQUEST['dinner'];
//$total_cal = $_REQUEST['total'];

$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://api.calorieninjas.com/v1/nutrition?query=$food_name",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_HTTPHEADER => [
		//"x-rapidapi-host: api.calorieninjas.com",
		"X-Api-Key: QjKxdrKafJnpdRrEi32kMA==3Oec6cCw9bXEu27P"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	 $response;
	 $msg['result']='success';
	 $someJSON = $response;
    // Convert JSON string to Array
    //$url = "https://bet247exch.com/game-list?key=cMT3I7ye1MPgB08C2FbuafQm6PwPCd0Ih4QerrMpkJF6rsC2cp&sport=cricket";
    $someArray=json_decode($someJSON,true);
    foreach($someArray['items'] as $item) {
        
    $mid=$item['calories'];
    $sql=mysqli_query($con,"INSERT INTO `tbl_calories`(`user_id`, `day`, `calorie`) VALUES('$user_id','$day','$mid')");
    }
}
echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
?>

 
 
 
        