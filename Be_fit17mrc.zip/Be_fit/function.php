<?php 
class Be_fit
{
  /*-------------user_login -------------*/
    function user_login()
    {
       include "config.php";
       $path="https://befit.beintl.com/Be_fit/profile_image/";
       $ibo_id = $_REQUEST['ibo_id'];
       $password = $_REQUEST['password'];
       $lg=mysqli_query($con,"select * from user_register where ibo_id='$ibo_id' and password='$password'");
       $lgg=mysqli_fetch_assoc($lg);
       $id=$lgg['ibo_id'];
       $pass=$lgg['password'];
       if($ibo_id==$id && $password==$pass)
       {
          $msg['result']='success';
          $msg['user_id']=$lgg['user_id'];
          $msg['name']=$lgg['name'];
          $msg['email']=$lgg['email'];
          $msg['contact']=$lgg['contact'];
          $msg['address']=$lgg['address'];
          $msg['profile_image']=$path.$lgg['images'];
       }
       else
       {
         $msg['result']='unsuccess';  
       }
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*-------------user_login -------------*/
   /*-------------insert_body_information------------*/
   function insert_body_information()
   {
       include "config.php";
       $ibo_id  = $_REQUEST['ibo_id'];
       $name  = $_REQUEST['name'];
       $dob  = $_REQUEST['dob'];
       $age  = $_REQUEST['age'];
       $gender  = $_REQUEST['gender'];
       $email  = $_REQUEST['email'];
       $phone  = $_REQUEST['phone'];
       $state  = $_REQUEST['state'];
       $country  = $_REQUEST['country'];
       $height  = $_REQUEST['height'];
       $weight  = $_REQUEST['weight'];
       $bmi  = $_REQUEST['bmi'];
       $body_fat  = $_REQUEST['body_fat'];
       $visceral_fat  = $_REQUEST['visceral_fat'];
       $skeletal_muscle  = $_REQUEST['skeletal_muscle'];
       $biological_age  = $_REQUEST['biological_age'];
      
      $inst=mysqli_query($con,"INSERT INTO `tbl_body_information`(`ibo_id`, `name`, `dob`, `age`, `gender`, `email`, `phone`, `state`, `country`, `height`, `weight`, `bmi`, `body_fat`, `visceral_fat`,
      `skeletal_muscle`, `biological_age`) VALUES ('$ibo_id','$name','$dob','$age','$gender','$email','$phone','$state','$country','$height','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age')");
      $id=mysqli_insert_id($con);
      if($id>0)
      {
        $msg['result']='success';  
        $msg['id']=$id;
      }
      else
      {
        $msg['result']='unsuccess';  
      }
      echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
   }
   /*-------------insert_body_information------------*/
   /*-------------temp_insert_body_information-----------*/
   function temp_insert_body_information()
   {
       include "config.php";
       $user_id = $_REQUEST['user_id'];
       $invoice_no = $_REQUEST['invoice_no'];
       $purchase_date = $_REQUEST['purchase_date'];
       $ibo_id  = $_REQUEST['ibo_id'];
       $name  = $_REQUEST['name'];
       $dob  = $_REQUEST['dob'];
       $age  = $_REQUEST['age'];
       $gender  = $_REQUEST['gender'];
       $email  = $_REQUEST['email'];
       $phone  = $_REQUEST['phone'];
       $state  = $_REQUEST['state'];
       $country  = $_REQUEST['country'];
       $height  = $_REQUEST['height'];
       $weight  = $_REQUEST['weight'];
       $bmi  = $_REQUEST['bmi'];
       $body_fat  = $_REQUEST['body_fat'];
       $visceral_fat  = $_REQUEST['visceral_fat'];
       $skeletal_muscle  = $_REQUEST['skeletal_muscle'];
       $biological_age  = $_REQUEST['biological_age'];
       
       $logo_image=$_REQUEST['front_image'];
       $logo_string=$_REQUEST['front_imagestring'];
       $new_img=str_replace(" ","",$logo_image);
       $image_binary=base64_decode($logo_string);
       $image_path="images/".$new_img;
       $file=fopen($image_path,'wb');
       $is_written=fwrite($file,$image_binary);
       //fclose($file);
       
       $logo_image1=$_REQUEST['back_image'];
       $logo_string1=$_REQUEST['back_imagestring'];
       $new_img1=str_replace(" ","",$logo_image1);
       $image_binary1=base64_decode($logo_string1);
       $image_path1="images/".$new_img1;
       $file1=fopen($image_path1,'wb');
       $is_written1=fwrite($file1,$image_binary1);
       
       $logo_image2=$_REQUEST['left_image'];
       $logo_string2=$_REQUEST['left_imagestring'];
       $new_img2=str_replace(" ","",$logo_image2);
       $image_binary2=base64_decode($logo_string2);
       $image_path2="images/".$new_img2;
       $file2=fopen($image_path2,'wb');
       $is_written2=fwrite($file2,$image_binary2);
        //fclose($file);
        
       $logo_image3=$_REQUEST['right_image'];
       $logo_string3=$_REQUEST['right_imagestring'];
       $new_img3=str_replace(" ","",$logo_image3);
       $image_binary3=base64_decode($logo_string3);
       $image_path3="images/".$new_img3;
       $file3=fopen($image_path3,'wb');
       $is_written3=fwrite($file3,$image_binary3);
        //fclose($file);   
       
       $logo_image4=$_REQUEST['screenshot_image'];
       $logo_string4=$_REQUEST['screenshot_imagestring'];
       $new_img4=str_replace(" ","",$logo_image4);
       $image_binary4=base64_decode($logo_string4);
       $image_path4="images/".$new_img4;
       $file4=fopen($image_path4,'wb');
       $is_written4=fwrite($file4,$image_binary4);
       //fclose($file);    
       
       /*$video = $_REQUEST['video'];
       $video_string=$_REQUEST['video_string'];
       $new_video=str_replace(" ","",$video);
       $video_binary=base64_decode($video_string);
       $video_path="video/".$new_video;
       $vfile=fopen($video_path,'wb');
       $is_written=fwrite($vfile,$video_binary);*/
       //fclose($vfile);
        $file_path = "video/";
        $file_path1 = basename( $_FILES['video']['name']);
        $new_video=str_replace(" ","",$file_path1);
        move_uploaded_file($_FILES['video']['tmp_name'], $file_path.$new_video);
        
       $inst=mysqli_query($con,"INSERT INTO `temp_body_information`(`user_id`,`invoice_no`,`purchase_date`,`ibo_id`, `name`, `dob`, `age`, `gender`, `email`, `phone`, `state`, `country`, `height`, `weight`, `bmi`,
       `body_fat`, `visceral_fat`, `skeletal_muscle`, `biological_age`, `front_image`, `back_image`, `left_image`, `right_image`, `screenshot_image`, `video`) 
       VALUES ('$user_id','$invoice_no','$purchase_date','$ibo_id','$name','$dob','$age','$gender','$email','$phone','$state','$country','$height','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age','$new_img',
       '$new_img1','$new_img2','$new_img3','$new_img4','$new_video')");
       $id=mysqli_insert_id($con);
       if($id>0)
       {
         $msg['result']='success';  
         $msg['id']=$id;  
       }
       else
       {
         $msg['result']='unsuccess';  
       }
       echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
   }
   /*-------------temp_insert_body_information-----------*/
   /*----------------fetch_temp_insert_body_information-----*/
   function fetch_temp_insert_body_information()
   {
       include "config.php";
       $id= $_REQUEST['id'];
       $url="https://befit.beintl.com/Be_fit/images/";
       $vde="https://befit.beintl.com/Be_fit/video/";
       $temp=mysqli_query($con,"select * from temp_body_information where temp_id='$id'");
       $tempp=mysqli_fetch_assoc($temp);
       $msg['user_id']=$tempp['user_id'];
       $msg['ibo_id']=$tempp['ibo_id'];
       $msg['name']=$tempp['name'];
       $msg['dob']=$tempp['dob'];
       $msg['age']=$tempp['age'];
       $msg['gender']=$tempp['gender'];
       $msg['email']=$tempp['email'];
       $msg['phone']=$tempp['phone'];
       $msg['state']=$tempp['state'];
       $msg['country']=$tempp['country'];
       $msg['height']=$tempp['height'];
       $msg['weight']=$tempp['weight'];
       $msg['bmi']=$tempp['bmi'];
       $msg['body_fat']=$tempp['body_fat'];
       $msg['visceral_fat']=$tempp['visceral_fat'];
       $msg['skeletal_muscle']=$tempp['skeletal_muscle'];
       $msg['biological_age']=$tempp['biological_age'];
       $msg['front_image']=$url.$tempp['front_image'];
       $msg['back_image']=$url.$tempp['back_image'];
       $msg['left_image']=$url.$tempp['left_image'];
       $msg['right_image']=$url.$tempp['right_image'];
       $msg['screenshot_image']=$url.$tempp['screenshot_image'];
       $msg['video']=$vde.$tempp['video'];
       
       array_walk_recursive($msg,function(&$item){$item=strval($item);});
       echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
   }
   /*----------------fetch_temp_insert_body_information-----*/
   /*----------delete_temp_information-------------*/
   function delete_temp_information()
   {
       include "config.php";
       $id = $_REQUEST['id'];
       $url="https://befit.beintl.com/Be_fit/images/";
       $vde="https://befit.beintl.com/Be_fit/video/";
       $temp=mysqli_query($con,"select * from temp_body_information where temp_id='$id'");
       $tempp=mysqli_fetch_assoc($temp);
       $uid=$tempp['user_id'];
       $ibo_id=$tempp['ibo_id'];
       $name=$tempp['name'];
       $dob=$tempp['dob'];
       $age=$tempp['age'];
       $gender=$tempp['gender'];
       $email=$tempp['email'];
       $phone=$tempp['phone'];
       $state=$tempp['state'];
       $country=$tempp['country'];
       $height=$tempp['height'];
       $weight=$tempp['weight'];
       $bmi=$tempp['bmi'];
       $body_fat=$tempp['body_fat'];
       $visceral_fat=$tempp['visceral_fat'];
       $skeletal_muscle=$tempp['skeletal_muscle'];
       $biological_age=$tempp['biological_age'];
       $front_image=$tempp['front_image'];
       $back_image=$tempp['back_image'];
       $left_image=$tempp['left_image'];
       $right_image=$tempp['right_image'];
       $screenshot_image=$tempp['screenshot_image'];
       $video=$tempp['video'];
       
       if($id!='')
       {
           date_default_timezone_set('Asia/Kolkata');
            $date = date('Y-m-d');
       $inst=mysqli_query($con,"INSERT INTO `tbl_body_information`(`temp_id`, `ibo_id`, `name`, `dob`, `age`, `gender`, `email`, `phone`, `state`, `country`, `height`, `weight`, `bmi`, `body_fat`, 
       `visceral_fat`, `skeletal_muscle`, `biological_age`, `front_image`, `back_image`, `left_image`, `right_image`, `screenshot_image`, `video`,`start_date`) 
       VALUES ('$uid','$ibo_id','$name','$dob','$age','$gender','$email','$phone','$state','$country','$height','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age',
       '$front_image','$back_image','$left_image','$right_image','$screenshot_image','$video','$date')");
       $del=mysqli_query($con,"delete from temp_body_information where temp_id='$id'");
       if($del)
       {
         $msg['result']='success';   
       }
       else
       {
          $msg['result']='unsuccess';  
       }
       }
       else
       {
          $msg['result']='unsuccess';  
       }
       echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
   }
   /*----------delete_temp_information-------------*/
   /*-----------------fetch_challenge_period----------*/
   function fetch_challenge_period()
   {
       include "config.php";
       
       date_default_timezone_set("Asia/Kolkata");
       $dd=date('Y-m-d');
       $per=mysqli_query($con,"select * from  tbl_challenges");
       while($perr=mysqli_fetch_assoc($per))
       {
          $arrays=array();
          $pert=mysqli_query($con,"select * from  tbl_challenges order by cid asc limit 1");
          $perrs=mysqli_fetch_assoc($pert);
          $msg1['challenge_id']=$perrs['cid']; 
          $msg1['title']=$perrs['title']; 
          $msg1['registration_period']=date('d M Y',strtotime($perrs['start_date'])).' '.'-'.' '.date('d M Y',strtotime($perrs['end_date']));
          $msg1['submission_date']=date('d M Y',strtotime($perrs['submission_date']));
          array_push($arrays,$msg1);
          
          array_walk_recursive($arrays,function(&$item){$item=strval($item);});
          echo json_encode($arrays,JSON_UNESCAPED_SLASHES);  
          die;
       }
   }
   /*-----------------fetch_challenge_period----------*/
   /*------------invite_friend---------------*/
   function invite_friend()
   {
       include "config.php";
       $ibo_id = $_REQUEST['ibo_id'];
       $user_id = $_REQUEST['user_id'];
       //$req_id = $_REQUEST['req_id'];
      
     
      
      $frn=mysqli_query($con,"select * from user_register where ibo_id='$ibo_id'");
      $frnn=mysqli_fetch_assoc($frn);
      $ib=$frnn['ibo_id'];
      $req_id=$frnn['user_id'];
      if($ibo_id!=$ib)
      {
        $msg['result']="Invalid ibo id";  
      }
      else
      {
      $upd=mysqli_query($con,"update user_register set request_status = 'request sent',friend_status='pending' where user_id='$user_id'");
      if($upd)
      {
      $uup=mysqli_query($con,"update user_register set request_status = 'frient request',friend_status='pending' where user_id='$req_id'");
      $inst=mysqli_query($con,"Insert into tbl_frnd_list(user_id,req_id,request_status,counting)values('$user_id','$req_id','Pending','0')");
      $num=mysqli_insert_id($con);
      $msg['id']=$num;
      
        $sel=mysqli_query($con,"select * from user_register where user_id='$req_id'");
        $roe=mysqli_fetch_assoc($sel);
       
        
        $selr=mysqli_query($con,"select * from user_register where user_id='$user_id'");
        $roee=mysqli_fetch_assoc($selr);
        $name=$roee['name'];
        $ibdi=$roee['ibo_id'];
        error_reporting(-1);
        ini_set('display_errors', 'On');
          $return_arry=array();
        require_once __DIR__ . '/firebase.php';
        require_once __DIR__ . '/push.php';
 
        $firebase = new Firebase();
        $push = new Push();
        
        // optional payload
        $payload = array();
        $payload['team'] = 'India';
        $payload['score'] = '5.6';

        // notification title
        $title='Friend Request';
     
        // notification message
         $message = $name." ".'Send Friend Request';
    
        $include_image = isset($_GET['include_image']) ? TRUE : FALSE;

        $push->setTitle($title);
        $push->setMessage($message);
        $push->setImage('');
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        $push->setibo_id($ibdi);
        $push->setname($name);
        
        $regId=$roe['andriod_device_id'];
        $json = '';
        $response = '';
        $json = $push->getPush();
        $response = $firebase->send($regId, $json);
        // $apnsServer = 'ssl://gateway.sandbox.push.apple.com:2195';
        // $privateKeyPassword = '1234';
        //  $sqli=mysqli_query($con,"select * from user_register where user_id='$req_id'");
        //      $fett=mysqli_fetch_assoc($sqli);
        //   $img=$fett['profile_image'];  
        // /* Put your own message here if you want to */
        // $message = $name." ".'Send Friend Request';
        // /* Pur your device token here */
        // $deviceToken =$fett['ios_device_id'];
        // $REGID=$row['andriod_device_id'];
        // $json = '';
        // $response = '';
        // $json = $push->getPush();
        // $response = $firebase->send($REGID, $json);
        // /* Replace this with the name of the file that you have placed by your PHP
        // script file, containing your private key and certificate that you generated
        // earlier */
        // $pushCertAndKeyPemFile = 'GoalGrabberDev_24Dec2020.pem';
        // $stream = stream_context_create();
        // stream_context_set_option($stream,
        // 'ssl',
        // 'passphrase',
        // $privateKeyPassword);
        // stream_context_set_option($stream,
        // 'ssl',
        // 'local_cert',
        // $pushCertAndKeyPemFile);

        // $connectionTimeout = 20;
        // $connectionType = STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT;
        // $connection = stream_socket_client($apnsServer,
        // $errorNumber,
        // $errorString,
        // $connectionTimeout,
        // $connectionType,
        // $stream);
        // // if (!$connection){
        // // echo "Failed to connect to the APNS server. Error no = $errorNumber<br/>";
        // // exit;
        // // } else {
        // // //echo "Successfully connected to the APNS. Processing...</br>";
        // // }
        // $messageBody['aps'] = array('alert' => $message,
        // 'sound' => 'default',
        // 'badge' => 2,
        // );
        // $payload = json_encode($messageBody);
        // $notification = chr(0) .
        // pack('n', 32) .
        // pack('H*', $deviceToken) .
        // pack('n', strlen($payload)) .
        // $payload;
        // $wroteSuccessfully = fwrite($connection, $notification, strlen($notification));
        date_default_timezone_set("Asia/Kolkata");
        $datet=date('Y-m-d H:i:s');
        $inst=mysqli_query($con,"INSERT INTO `tbl_notification`(`user_id`, `image`, `msg`, `date_time`)values('$req_id','','$message','$datet')");
        // if (!$wroteSuccessfully){
        // $msg['result']='unsuccess';
        // }
        // else {
         $msg['result']='success';
        //}
        //fclose($connection);
     
  }
  else
  {
    $msg['result']='unsuccess';  
  }}
  echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
       die;
   }
   /*------------invite_friend---------------*/
   /*---------accept_friend_req----------*/
   function accept_friend_req()
{
  include "config.php"; 
  $user_id = $_REQUEST['user_id'];
  //$req_id = $_REQUEST['req_id'];
  $status = $_REQUEST['status'];
  if($status=='Accept')
  {
   $sef=mysqli_query($con,"select * from tbl_frnd_list where req_id='$user_id'");
   $sef1=mysqli_fetch_assoc($sef);
   $cunt = $sef1['counting'];
   $uid=$sef1['user_id'];
   $req_id =$sef1['req_id'];
   $upd=mysqli_query($con,"update tbl_frnd_list set counting='$cunt'+1,request_status='Accept' where user_id='$uid' ");
  if($upd)
  {
      //$msg['result']='success';
       $sel=mysqli_query($con,"select * from user_register where user_id='$uid'");
        $roe=mysqli_fetch_assoc($sel);
        
        
        $serl=mysqli_query($con,"select * from user_register where user_id='$user_id'");
        $roer=mysqli_fetch_assoc($serl);
        $name=$roer['name'];
        error_reporting(-1);
        ini_set('display_errors', 'On');
          $return_arry=array();
        require_once __DIR__ . '/firebase.php';
        require_once __DIR__ . '/push.php';
 
        $firebase = new Firebase();
        $push = new Push();
        
        // optional payload
        $payload = array();
        $payload['team'] = 'India';
        $payload['score'] = '5.6';

        // notification title
        $title='Accept Notification';
     
         /* Put your own message here if you want to */
        $message = $name." ".'Accept Friend Request';
    
        $include_image = isset($_GET['include_image']) ? TRUE : FALSE;

        $push->setTitle($title);
        $push->setMessage($message);
        $push->setImage('');
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        
        $regId=$roe['andriod_device_id'];
        $json = '';
        $response = '';
        $json = $push->getPush();
        $response = $firebase->send($regId, $json);
        // $apnsServer = 'ssl://gateway.sandbox.push.apple.com:2195';
        // $privateKeyPassword = '1234';
        // $sqli=mysqli_query($con,"select * from user_register where user_id='$req_id'");
        // $fett=mysqli_fetch_assoc($sqli);
        // $img=$fett['profile_image'];  
       
        // /* Pur your device token here */
        // $deviceToken =$fett['ios_device_id'];
        // $REGID=$row['andriod_device_id'];
        // $json = '';
        // $response = '';
        // $json = $push->getPush();
        // $response = $firebase->send($REGID, $json);
        // /* Replace this with the name of the file that you have placed by your PHP
        // script file, containing your private key and certificate that you generated
        // earlier */
        // $pushCertAndKeyPemFile = 'GoalGrabberDev_24Dec2020.pem';
        // $stream = stream_context_create();
        // stream_context_set_option($stream,
        // 'ssl',
        // 'passphrase',
        // $privateKeyPassword);
        // stream_context_set_option($stream,
        // 'ssl',
        // 'local_cert',
        // $pushCertAndKeyPemFile);

        // $connectionTimeout = 20;
        // $connectionType = STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT;
        // $connection = stream_socket_client($apnsServer,
        // $errorNumber,
        // $errorString,
        // $connectionTimeout,
        // $connectionType,
        // $stream);
        // // if (!$connection){
        // // echo "Failed to connect to the APNS server. Error no = $errorNumber<br/>";
        // // exit;
        // // } else {
        // // //echo "Successfully connected to the APNS. Processing...</br>";
        // // }
        // $messageBody['aps'] = array('alert' => $message,
        // 'sound' => 'default',
        // 'badge' => 2,
        // );
        // $payload = json_encode($messageBody);
        // $notification = chr(0) .
        // pack('n', 32) .
        // pack('H*', $deviceToken) .
        // pack('n', strlen($payload)) .
        // $payload;
        // $wroteSuccessfully = fwrite($connection, $notification, strlen($notification));
        date_default_timezone_set("Asia/Kolkata");
        $datet=date('Y-m-d H:i:s');
        $inst=mysqli_query($con,"INSERT INTO `tbl_notification`(`user_id`, `image`, `msg`, `date_time`)values('$uid','','$message','$datet')");
        // if (!$wroteSuccessfully){
        // $msg['result']='unsuccess';
        // }
        // else {
         $msg['result']='accept success';
        //}
        //fclose($connection);
  }
  else
  {
    $msg['result']='unsuccess';  
  }
  }
  elseif($status=='Reject')
  {
      
    $sef=mysqli_query($con,"select * from tbl_frnd_list where req_id='$user_id'");
   $sef1=mysqli_fetch_assoc($sef);
   $cunt = $sef1['counting'];
   $uid=$sef1['user_id'];
   $req_id =$sef1['req_id'];
   $upd=mysqli_query($con,"update tbl_frnd_list set counting='$cunt'-1,request_status='Reject' where user_id='$uid' ");
  if($upd)
  {
      //$msg['result']='success';
       $sel=mysqli_query($con,"select * from user_register where user_id='$uid'");
        $roe=mysqli_fetch_assoc($sel);
        
        
        $serl=mysqli_query($con,"select * from user_register where user_id='$user_id'");
        $roer=mysqli_fetch_assoc($serl);
        $name=$roer['name'];
        error_reporting(-1);
        ini_set('display_errors', 'On');
          $return_arry=array();
        require_once __DIR__ . '/firebase.php';
        require_once __DIR__ . '/push.php';
 
        $firebase = new Firebase();
        $push = new Push();
        
        // optional payload
        $payload = array();
        $payload['team'] = 'India';
        $payload['score'] = '5.6';

        // notification title
        $title='Reject Notification';
     
         /* Put your own message here if you want to */
        $message = $name." ".'Reject Friend Request';
    
        $include_image = isset($_GET['include_image']) ? TRUE : FALSE;

        $push->setTitle($title);
        $push->setMessage($message);
        $push->setImage('');
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        
        $regId=$roe['andriod_device_id'];
        $json = '';
        $response = '';
        $json = $push->getPush();
        $response = $firebase->send($regId, $json);
        // $apnsServer = 'ssl://gateway.sandbox.push.apple.com:2195';
        // $privateKeyPassword = '1234';
        // $sqli=mysqli_query($con,"select * from user_register where user_id='$req_id'");
        // $fett=mysqli_fetch_assoc($sqli);
        // $img=$fett['profile_image'];  
       
        // /* Pur your device token here */
        // $deviceToken =$fett['ios_device_id'];
        // $REGID=$row['andriod_device_id'];
        // $json = '';
        // $response = '';
        // $json = $push->getPush();
        // $response = $firebase->send($REGID, $json);
        // /* Replace this with the name of the file that you have placed by your PHP
        // script file, containing your private key and certificate that you generated
        // earlier */
        // $pushCertAndKeyPemFile = 'GoalGrabberDev_24Dec2020.pem';
        // $stream = stream_context_create();
        // stream_context_set_option($stream,
        // 'ssl',
        // 'passphrase',
        // $privateKeyPassword);
        // stream_context_set_option($stream,
        // 'ssl',
        // 'local_cert',
        // $pushCertAndKeyPemFile);

        // $connectionTimeout = 20;
        // $connectionType = STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT;
        // $connection = stream_socket_client($apnsServer,
        // $errorNumber,
        // $errorString,
        // $connectionTimeout,
        // $connectionType,
        // $stream);
        // // if (!$connection){
        // // echo "Failed to connect to the APNS server. Error no = $errorNumber<br/>";
        // // exit;
        // // } else {
        // // //echo "Successfully connected to the APNS. Processing...</br>";
        // // }
        // $messageBody['aps'] = array('alert' => $message,
        // 'sound' => 'default',
        // 'badge' => 2,
        // );
        // $payload = json_encode($messageBody);
        // $notification = chr(0) .
        // pack('n', 32) .
        // pack('H*', $deviceToken) .
        // pack('n', strlen($payload)) .
        // $payload;
        // $wroteSuccessfully = fwrite($connection, $notification, strlen($notification));
        date_default_timezone_set("Asia/Kolkata");
        $datet=date('Y-m-d H:i:s');
        $inst=mysqli_query($con,"INSERT INTO `tbl_notification`(`user_id`, `image`, `msg`, `date_time`)values('$uid','','$message','$datet')");
        // if (!$wroteSuccessfully){
        // $msg['result']='unsuccess';
        // }
        // else {
         $msg['result']='reject success';
        //}
        //fclose($connection);
  }
  else
  {
    $msg['result']='unsuccess';  
  }
  }
  echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
       die;
}
/*-------------accept_friend_req-------------------*/
   /*--------------update_android_device_id------------*/
    function update_android_device_id()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        $device_id = $_REQUEST['device_id'];
        
        if($user_id!=='' && $device_id!=='')
        {
        $upd=mysqli_query($con,"update user_register set andriod_device_id='$device_id',device_status='Android' where user_id='$user_id'");
        //echo die(mysqli_error($con));
        if($upd)
        {
           $msg['result']='success'; 
        }
        else
        {
          $msg['result']='unsuccess';   
        }
        }
        else
        {
           $msg['result']='unsuccess'; 
        }
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*--------------update_android_device_id------------*/
    /*------------------temp_after_information----------*/
    function temp_after_information()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        //$height = $_REQUEST['height'];
        $weight = $_REQUEST['weight'];
        $bmi = $_REQUEST['bmi'];
        $body_fat = $_REQUEST['body_fat'];
        $visceral_fat = $_REQUEST['visceral_fat'];
        $skeletal_muscle = $_REQUEST['skeletal_muscle'];
        $biological_age = $_REQUEST['biological_age'];
        $weighttext = $_REQUEST['weighttext'];
        $supplytext = $_REQUEST['supplytext'];
        
         $logo_image=$_REQUEST['front_image'];
       $logo_string=$_REQUEST['front_imagestring'];
       $new_img=str_replace(" ","",$logo_image);
       $image_binary=base64_decode($logo_string);
       $image_path="images/".$new_img;
       $file=fopen($image_path,'wb');
       $is_written=fwrite($file,$image_binary);
       //fclose($file);
       
       $logo_image1=$_REQUEST['back_image'];
       $logo_string1=$_REQUEST['back_imagestring'];
       $new_img1=str_replace(" ","",$logo_image1);
       $image_binary1=base64_decode($logo_string1);
       $image_path1="images/".$new_img1;
       $file1=fopen($image_path1,'wb');
       $is_written1=fwrite($file1,$image_binary1);
       
       $logo_image2=$_REQUEST['left_image'];
       $logo_string2=$_REQUEST['left_imagestring'];
       $new_img2=str_replace(" ","",$logo_image2);
       $image_binary2=base64_decode($logo_string2);
       $image_path2="images/".$new_img2;
       $file2=fopen($image_path2,'wb');
       $is_written2=fwrite($file2,$image_binary2);
        //fclose($file);
        
       $logo_image3=$_REQUEST['right_image'];
       $logo_string3=$_REQUEST['right_imagestring'];
       $new_img3=str_replace(" ","",$logo_image3);
       $image_binary3=base64_decode($logo_string3);
       $image_path3="images/".$new_img3;
       $file3=fopen($image_path3,'wb');
       $is_written3=fwrite($file3,$image_binary3);
        //fclose($file);
        
        //video code
       $file_path = "video/";
       $file_path1 = basename( $_FILES['video']['name']);
       $new_video=str_replace(" ","",$file_path1);
       move_uploaded_file($_FILES['video']['tmp_name'], $file_path.$new_video); 
       
       //weight doc
       $file_path1 = "document/";
       $file_path11 = basename( $_FILES['weightdocfile']['name']);
       $new_doc=str_replace(" ","",$file_path11);
       move_uploaded_file($_FILES['weightdocfile']['tmp_name'], $file_path1.$new_doc); 
       
        //supply doc code
       $file_path2 = "document/";
       $file_path12 = basename( $_FILES['supplydocfile']['name']);
       $new_supply=str_replace(" ","",$file_path12);
       move_uploaded_file($_FILES['supplydocfile']['tmp_name'], $file_path2.$new_supply); 
       
       $inst=mysqli_query($con,"INSERT INTO `temp_after_info`(`user_id`,`height`, `weight`, `bmi`, `body_fat`, `visceral_fat`, `skeletal_muscle`, `biological_age`, `weighttext`, `supplytext`, `front_image`, `back_image`, `left_image`, `right_image`, `video`, `weightdocfile`, `supplydocfile`) 
       VALUES('$user_id','','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age','$weighttext','$supplytext','$new_img','$new_img1','$new_img2','$new_img3','$new_video','$new_doc','$new_supply')");
       $id=mysqli_insert_id($con);
        if($id>0)
        {
          $msg['temp_after_id']=$id;    
          $msg['result']='success';  
        }
        else
        {
         $msg['result']='unsuccess';    
        }
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*------------------temp_after_information----------*/
    /*------------fetch_after_info--------------*/
    function fetch_after_info()
    {
        include "config.php";
        $id = $_REQUEST['id'];
        $url="https://befit.beintl.com/Be_fit/images/";
        $vde="https://befit.beintl.com/Be_fit/video/";
        $doc="https://befit.beintl.com/Be_fit/document/";
        $qaz=mysqli_query($con,"select * from temp_after_info where aid='$id'");
        $qazz=mysqli_fetch_assoc($qaz);
        
        $msg['user_id']=$qazz['user_id'];
        $msg['weight']=$qazz['weight'];
        $temp=mysqli_query($con,"select * from temp_body_information where user_id='".$qazz['user_id']."'");
        $tempp=mysqli_fetch_assoc($temp);
        $msg['height']=$tempp['height'];
        $msg['bmi']=$qazz['bmi'];
        $msg['body_fat']=$qazz['body_fat'];
        $msg['visceral_fat']=$qazz['visceral_fat'];
        $msg['skeletal_muscle']=$qazz['skeletal_muscle'];
        $msg['biological_age']=$qazz['biological_age'];
        $msg['weighttext']=$qazz['weighttext'];
        $msg['supplytext']=$qazz['supplytext'];
        $msg['front_image']=$url.$qazz['front_image'];
        $msg['back_image']=$url.$qazz['back_image'];
        $msg['left_image']=$url.$qazz['left_image'];
        $msg['right_image']=$url.$qazz['right_image'];
        $msg['video']=$vde.$qazz['video'];
        $msg['weightdocfile']=$doc.$qazz['weightdocfile'];
        $msg['supplydocfile']=$doc.$qazz['supplydocfile'];
        array_walk_recursive($msg,function(&$item){$item=strval($item);});
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*------------fetch_afetr_info--------------*/
    /*------------delete_temp_after_info--------------*/
    function delete_temp_after_info()
    {
        include "config.php";
        $id = $_REQUEST['id'];
       $url="https://befit.beintl.com/Be_fit/images/";
       $vde="https://befit.beintl.com/Be_fit/video/";
       $temp=mysqli_query($con,"select * from temp_after_info where aid='$id'");
       $tempp=mysqli_fetch_assoc($temp);
       $uid=$tempp['user_id'];
       $weight=$tempp['weight'];
       //$height=$tempp['height'];
       $bmi=$tempp['bmi'];
       $body_fat=$tempp['body_fat'];
       $visceral_fat=$tempp['visceral_fat'];
       $skeletal_muscle=$tempp['skeletal_muscle'];
       $biological_age=$tempp['biological_age'];
       $weighttext=$tempp['weighttext'];
       $supplytext=$tempp['supplytext'];
       $front_image=$tempp['front_image'];
       $back_image=$tempp['back_image'];
       $left_image=$tempp['left_image'];
       $right_image=$tempp['right_image'];
       $video=$tempp['video'];
       $weightdocfile=$tempp['weightdocfile'];
       $supplydocfile=$tempp['supplydocfile'];
       
       if($id!='')
       {
           date_default_timezone_set('Asia/Kolkata');
            $date = date('Y-m-d');
            
       $inst=mysqli_query($con,"INSERT INTO `tbl_after_body_info`(`user_id`,`height`, `weight`, `bmi`, `body_fat`, `visceral_fat`, `skeletal_muscle`, `biological_age`, `weighttext`, `supplytext`,
       `front_image`, `back_image`, `left_image`, `right_image`, `video`, `weightdocfile`, `supplydocfile`,`end_date`) 
       VALUES ('$uid','','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age','$weighttext','$supplytext','$front_image','$back_image',
       '$left_image','$right_image','$video','$weightdocfile','$supplydocfile','$date')");
      
       if($inst)
       {
         $msg['result']='success'; 
          $del=mysqli_query($con,"delete from temp_after_info where aid='$id'");
       }
       else
       {
          $msg['result']='unsuccess';  
       }
       }
       else
       {
          $msg['result']='unsuccess';  
       }
       echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*------------delete_temp_after_info--------------*/
    /*-------fetch_overall_summary---------------*/
    function fetch_overall_summary()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        $url="https://befit.beintl.com/Be_fit/images/";
        $ssw=mysqli_query($con,"select * from tbl_body_information where temp_id='$user_id'");
        $ssww=mysqli_fetch_assoc($ssw);
        
        $msg['name']=$ssww['name'];
        $msg['height']=$ssww['height'];
        $msg['before_weight']=$ssww['weight'];
        $msg['before_bmi']=$ssww['bmi'];
        $msg['before_body_fat']=$ssww['body_fat'];
        $msg['before_visceral_fat']=$ssww['visceral_fat'];
        $msg['before_skeletal_muscle']=$ssww['skeletal_muscle'];
        $msg['before_biological_age']=$ssww['biological_age'];
        $msg['before_front_image']=$url.$ssww['front_image'];
        $msg['before_back_image']=$url.$ssww['back_image'];
        $msg['before_left_image']=$url.$ssww['left_image'];
        $msg['before_right_image']=$url.$ssww['right_image'];
        $msg['start_date']=$ssww['start_date'];
        
        $ssq=mysqli_query($con,"select * from tbl_after_body_info where user_id='$user_id'");
        $ssqq=mysqli_fetch_assoc($ssq);
        $msg['after_weight']=$ssqq['weight'];
        $msg['after_bmi']=$ssqq['bmi'];
        $msg['after_body_fat']=$ssqq['body_fat'];
        $msg['after_visceral_fat']=$ssqq['visceral_fat'];
        $msg['after_skeletal_muscle']=$ssqq['skeletal_muscle'];
        $msg['after_biological_age']=$ssqq['biological_age'];
        $msg['after_front_image']=$url.$ssqq['front_image'];
        $msg['after_back_image']=$url.$ssqq['back_image'];
        $msg['after_left_image']=$url.$ssqq['left_image'];
        $msg['after_right_image']=$url.$ssqq['right_image'];
        $msg['end_date']=$ssqq['end_date'];
        
        $msg['changes_weight']=$ssww['weight']-$ssqq['weight'];
        $msg['changes_bmi']=$ssww['bmi']-$ssqq['bmi'];;
        $msg['changes_body_fat']=$ssww['body_fat']-$ssqq['body_fat'];
        $msg['changes_visceral_fat']=$ssww['visceral_fat']-$ssqq['visceral_fat'];
        $msg['changes_skeletal_muscle']=$ssww['skeletal_muscle']-$ssqq['skeletal_muscle'];
        $msg['changes_biological_age']=$ssww['biological_age']-$ssqq['biological_age'];
        array_walk_recursive($msg,function(&$item){$item=strval($item);});
         echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*-------fetch_overall_summary---------------*/
    /*---------user_daily_info------------------*/
    function user_daily_info()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        $weight = $_REQUEST['weight'];
        $bmi = $_REQUEST['bmi'];
        $body_fat = $_REQUEST['body_fat'];
        $visceral_fat = $_REQUEST['visceral_fat'];
        $skeletal_muscle = $_REQUEST['skeletal_muscle'];
        $biological_age = $_REQUEST['biological_age'];
        
        $rf=mysqli_query($con,"select sum(calorie)as total from tbl_calories where user_id='$user_id'");
        $rff=mysqli_fetch_assoc($rf);
        
        $calorie=$rff['total'];
        
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d');
        $inst=mysqli_query($con,"INSERT INTO `tbl_daily_info`(`user_id`, `weight`, `bmi`, `body_fat`, `visceral_fat`, `skeletal_muscle`, `biological_age`, `date`, `day`,`calorie_data`,`total_cal`) 
        VALUES('$user_id','$weight','$bmi','$body_fat','$visceral_fat','$skeletal_muscle','$biological_age','$date','','','$calorie')");
        $id=mysqli_insert_id($con);
        if($id>0)
        {
            $dy='Day'.''.$id;
            $upd=mysqli_query($con,"update tbl_daily_info set day='$dy' where did='$id'");
          $msg['result']='success';  
          $msg['daily_id']=$id;  
        }
        else
        {
          $msg['result']='unsuccess';   
        }
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*---------user_daily_info------------------*/
    /*---------fetch_user_daily_info--------*/
    function fetch_user_daily_info()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        
        $daly=mysqli_query($con,"select * from tbl_daily_info where user_id='$user_id'");
        $row=mysqli_fetch_assoc($daly);
        
        $msg['weight']=$row['weight'];
        $msg['bmi']=$row['bmi'];
        $msg['body_fat']=$row['body_fat'];
        $msg['visceral_fat']=$row['visceral_fat'];
        $msg['skeletal_muscle']=$row['skeletal_muscle'];
        $msg['biological_age']=$row['biological_age'];
        $arr=array();
        $rf=mysqli_query($con,"select * from tbl_calories where user_id='$user_id'");
        while($rff=mysqli_fetch_assoc($rf))
        {
        $ms['day']=$rff['day'];
        $ms['calorie']=$rff['calorie'];
        array_push($arr,$ms);
        }
        $msg['total_cal']=$row['total_cal'];
        $msg['calory_detail']=$arr;
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*---------fetch_user_daily_info--------*/
    /*--------------update_ios_device_id------------*/
    function update_ios_device_id()
    {
        include "config.php";
        $user_id = $_REQUEST['user_id'];
        $device_id = $_REQUEST['device_id'];
        
        if($user_id!=='' && $device_id!=='')
        {
        $upd=mysqli_query($con,"update user_register set ios_device_id='$device_id',device_status='Ios' where user_id='$user_id'");
        //echo die(mysqli_error($con));
        if($upd)
        {
           $msg['result']='success'; 
        }
        else
        {
          $msg['result']='unsuccess';   
        }
        }
        else
        {
           $msg['result']='unsuccess'; 
        }
        echo json_encode($msg,JSON_UNESCAPED_SLASHES);  
         die;
    }
    /*--------------update_ios_device_id------------*/
}
?>