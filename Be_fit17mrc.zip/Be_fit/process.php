<?php
include('function.php');
if(isset($_REQUEST['action']) && $_REQUEST['action']=='user_login')
{
 $obj = new Be_fit();
 $obj->user_login();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='insert_body_information')
{
 $obj = new Be_fit();
 $obj->insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='temp_insert_body_information')
{
 $obj = new Be_fit();
 $obj->temp_insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_temp_insert_body_information')
{
 $obj = new Be_fit();
 $obj->fetch_temp_insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='delete_temp_information')
{
 $obj = new Be_fit();
 $obj->delete_temp_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_challenge_period')
{
 $obj = new Be_fit();
 $obj->fetch_challenge_period();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='update_android_device_id')
{
 $obj = new Be_fit();
 $obj->update_android_device_id();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='invite_friend')
{
 $obj = new Be_fit();
 $obj->invite_friend();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='accept_friend_req')
{
 $obj = new Be_fit();
 $obj->accept_friend_req();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='temp_after_information')
{
 $obj = new Be_fit();
 $obj->temp_after_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_after_info')
{
 $obj = new Be_fit();
 $obj->fetch_after_info();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='delete_temp_after_info')
{
 $obj = new Be_fit();
 $obj->delete_temp_after_info();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_overall_summary')
{
 $obj = new Be_fit();
 $obj->fetch_overall_summary();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='user_daily_info')
{
 $obj = new Be_fit();
 $obj->user_daily_info();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='food_calorie_api')
{
 $obj = new Be_fit();
 $obj->food_calorie_api();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_user_daily_info')
{
 $obj = new Be_fit();
 $obj->fetch_user_daily_info();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='update_ios_device_id')
{
 $obj = new Be_fit();
 $obj->update_ios_device_id();
}
?>