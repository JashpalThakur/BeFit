<?php
include('config.php');
if(session_destroy())
{
unset($_SESSION["id"]);
header("location:login.php");
}
?>