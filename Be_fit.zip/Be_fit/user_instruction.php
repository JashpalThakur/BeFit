<html>
    <head>
        <style>
        .content {
  width:100%;
  margin:0;
}
.content h1{
  font-size:45px;
  text-align:left;
}




#accordion div {
  position:relative;
  margin:0 0 0;
  padding:15px;
  color:#fff;
  background:transparent;
  display: block;
  color:#000;
  
}

#accordion div:after {
position: absolute;
top: -31px;
right: 7%;
display: block;
width: 0;
height: 0;
margin-left: -20px;
border-width: 15px;
border-style: solid;
border-color: transparent transparent  rgb(127,147,138)  transparent;
z-index:1;
content: '';
}
</style>
    </head>
    <!--<div class="text-center">-->
    <!--                     <a href="dashboard.php" class="logo-lg"><img src="dist/img/logo.png" style="width: 9%;margin-top: 0px;margin-bottom: -165px;margin-left: 600px;"> </a>-->
    <!--                </div>-->
<body style="border:5px solid #358093;text-align:center;padding:10px;text-align:justify;">
<div class="content">
    <div>
  <center><h1></h1></center>  
  <div>


<div >
  <h3>User Instructions</h3>
  <div>
   
  </div>
  <h4>Requirements</h4>
  <div>1. Before photos & video<br>
       2. Purchase specific promo pack<br>
       3. After photos & video<br>
       4. Weight management journey story (250-500 words)<br>
       5. Like Belixz FB/ IG page</div>
  <hr>
  <h4>How To Participate?</h4>
  <div>1. Open to all BE IBOs.<br>
2. Each entry comes in a pair of 2 IBOs within the same country. Both IBOs within the same pairing must start and end on the same date.<br>
3. Each IBO has to upload Before photos (front, back, left & right side view) with a time stamp on it.<br>
4. Each IBO has to upload a Before video clip of you standing on a weighing scale and a close shot on the reading of the weighing scale.<br>
5. Each IBO has to upload the receipt of purchase for the specific package. One invoice is only eligible to participate in the on-going season based on the date of purchase.<br>
6. To complete, each IBO has to submit the After photos, video and weight management journey story in 250-500 words after the 90 days challenge.<br>
7. Both IBOs within the same pairing must complete all submission to be considered as ULTIMATE COMPLETION and lose at least a minimum of 5kg each person to be eligible for judging.<br>
8. Incomplete submission or late submission of any IBO within the same pairing will cause the whole pairing to be automatically be disqualified from the challenge.</div>
  <hr>
</div>

<script>
    $(function() {
    $("#accordion").accordion({
            active: false,
            autoHeight: false,
            navigation: true,
            collapsible: true,
      event: "mouseover"
        });
});
</script>
<!--<footer>
                      <center><p>
                &copy; <span id="copy-year">2020</span> Copyright COVID Contact Tracing  by
                 <a class="text-primary" href="https://cisswork.com/" target="_blank">Ciss</a>.
              </p></center>
              <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script></footer>-->
</body>
</html>