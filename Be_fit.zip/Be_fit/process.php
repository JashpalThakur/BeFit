<?php
include('function.php');
if(isset($_REQUEST['action']) && $_REQUEST['action']=='user_login')
{
 $obj = new Be_fit();
 $obj->user_login();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='insert_body_information')
{
 $obj = new Be_fit();
 $obj->insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='temp_insert_body_information')
{
 $obj = new Be_fit();
 $obj->temp_insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_temp_insert_body_information')
{
 $obj = new Be_fit();
 $obj->fetch_temp_insert_body_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='delete_temp_information')
{
 $obj = new Be_fit();
 $obj->delete_temp_information();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='fetch_challenge_period')
{
 $obj = new Be_fit();
 $obj->fetch_challenge_period();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='update_android_device_id')
{
 $obj = new Be_fit();
 $obj->update_android_device_id();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='invite_friend')
{
 $obj = new Be_fit();
 $obj->invite_friend();
}
elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='accept_friend_req')
{
 $obj = new Be_fit();
 $obj->accept_friend_req();
}
?>