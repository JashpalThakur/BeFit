<?php function validCheckSum($checksumStr,$checksum, $secret)
{ $finalCheckSum = md5($checksumStr.$secret); return strcmp($finalCheckSum, $checksum) == 0; }
$secret = "PUDbbNKeW9qTrNwLMbWppIQ5sEQB7P5L"; 
//change your secret key here. 
$status_code = $_POST["status_code"]; 
$member_code = $_POST["member_code"];
$member_name = $_POST["member_name"]; 
$timestamp = $_POST["timestamp"]; 
$checksum = $_POST["checksum"]; 
$checkSumStr = $status_code.$member_code.$member_name.$timestamp; 
$validCheckSum = validCheckSum($checkSumStr, $checksum, $secret); 
if($validCheckSum) { ?> 
Status Code : <?php print $status_code ?> <br/>
Member Code : <?php print $member_code ?> <br/> 
Member Name : <?php print $member_name ?> <br/> 
TimeStamp : <?php print $timestamp ?> <br/> 
<?php }else{ echo "invalid checksum!!"; } 
?>