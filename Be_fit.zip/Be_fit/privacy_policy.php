<html>
    <head>
        <style>
        .content {
  width:100%;
  margin:0;
}
.content h1{
  font-size:45px;
  text-align:left;
}




#accordion div {
  position:relative;
  margin:0 0 0;
  padding:15px;
  color:#fff;
  background:transparent;
  display: block;
  color:#000;
  
}

#accordion div:after {
position: absolute;
top: -31px;
right: 7%;
display: block;
width: 0;
height: 0;
margin-left: -20px;
border-width: 15px;
border-style: solid;
border-color: transparent transparent  rgb(127,147,138)  transparent;
z-index:1;
content: '';
}
</style>
    </head>
    <!--<div class="text-center">-->
    <!--                     <a href="dashboard.php" class="logo-lg"><img src="dist/img/logo.png" style="width: 9%;margin-top: 0px;margin-bottom: -165px;margin-left: 600px;"> </a>-->
    <!--                </div>-->
<body style="border:5px solid #358093;text-align:center;padding:10px;text-align:justify;">
<div class="content">
    <div>
  <center><h1></h1></center>  
  <div>


<div >
  <h3>User Privacy Policy</h3>
  <div>
   
  </div>
  <h4>Privacy Policy</h4>
  <div>It is a type of agreement required by law for those who use or collect any personal data on websites or mobile applications. </div>
  <hr>
<!--  <h4>Judging Periods</h4>-->
<!--  <div>• The registration period for each season is 2 months.<br>-->
<!--  • Each participating period is 90 days starting from the Initial Submission date.<br>-->
<!--• Every entry consists of a pair of IBOs (2 pax) within the same country.<br>-->
<!--• Each participant is required to submit Before, After photos, video, story, receipt of purchase and a screenshot of Like Belixz FB Page to be eligible for judging.<br>-->
<!--• Incomplete submission or late submission will cause the participant to be automatically disqualified from the challenge.</div>-->
<!--  <hr>-->
</div>

<script>
    $(function() {
    $("#accordion").accordion({
            active: false,
            autoHeight: false,
            navigation: true,
            collapsible: true,
      event: "mouseover"
        });
});
</script>
<!--<footer>
                      <center><p>
                &copy; <span id="copy-year">2020</span> Copyright COVID Contact Tracing  by
                 <a class="text-primary" href="https://cisswork.com/" target="_blank">Ciss</a>.
              </p></center>
              <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script></footer>-->
</body>
</html>